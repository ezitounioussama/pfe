<?php



if (isset($_POST['submit'])) {
    $log = $_POST['name'];
    // $passe = md5($_POST['pass']);
    $passe = $_POST['pass'];
    $dbh = new PDO('mysql:host=localhost;dbname=webapp', $user = "root", $pass = "");
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $dbh->prepare('SELECT * FROM login WHERE name=? and pass=?');
    $parametres = array($log, $passe);
    $stmt->execute($parametres);
    if ($rs = $stmt->fetch()) {
        session_start();
        $_SESSION['droit'] = $rs;
        if ($rs['function'] == "admin") {
            header('location:../admin/home.php');
        } elseif ($rs['function'] == "user") {
            header('location:../user_interface/');
        }
    } else {
        header('location:../error.php');
    }
}
