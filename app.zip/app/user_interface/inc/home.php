<header class="header-2">
  <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-inner mb-4">
      <div class="carousel-item">
        <div class="page-header min-vh-75 m-3 border-radius-xl" style="background-image: url('./assets/img/slide1.jpg');">

          <span class="mask bg-gradient-dark"></span>
          <div class="container">
            <div class="row">
              <div class="col-lg-6 my-auto">
                <h4 class="text-white mb-0 fadeIn1 fadeInBottom">Pricing Plans</h4>
                <h1 class="text-white fadeIn2 fadeInBottom">Buy from E-mobile and save ur money</h1>
                <p class="lead text-white opacity-8 fadeIn3 fadeInBottom">You'll find what you want here and you can't imagine the prices</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="carousel-item active">
        <div class="page-header min-vh-75 m-3 border-radius-xl" style="background-image: url('./assets/img/slide2.jpg');">
          <span class="mask bg-gradient-dark"></span>
          <div class="container">
            <div class="row">
              <div class="col-lg-6 my-auto">
                <h4 class="text-white mb-0 fadeIn1 fadeInBottom">Best Phones</h4>
                <h1 class="text-white fadeIn2 fadeInBottom">Buy from home</h1>
                <p class="lead text-white opacity-8 fadeIn3 fadeInBottom">You’re spending time to save money when you should be spending money to save time.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="min-vh-75 position-absolute w-100 top-0">
      <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-bs-slide="prev">
        <span class="carousel-control-prev-icon position-absolute bottom-50" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
      </a>
      <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-bs-slide="next">
        <span class="carousel-control-next-icon position-absolute bottom-50" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
      </a>
    </div>
  </div>
</header>

<!-- Products -->

<div class="card card-body blur shadow-blur p-5 mx-3 mx-md-4 mt-n6">





  <div class="container ">
    <div class="row">
      <div class="row justify-content-center text-center my-sm-5">
        <div class="col-lg-6">

          <h2 class="text-dark mb-0">Huge collection of phones</h2>
          <p class="lead">We choose a collection of the best phones we have</p>
        </div>
      </div>
    </div>
  </div>



  <!-- Random Products -->


  <div class="card-group mt-6 mb-2">
    <?php
    include_once('../db/connection.php');
    $a = 1;
    $stmt = $dbh->prepare(
      "SELECT * FROM products ORDER BY RAND() limit 3"
    );
    $stmt->execute();
    $users = $stmt->fetchAll();
    foreach ($users as $user) {
    ?>
      <div class="card d-flex  align-items-center mb-7" data-animation="true">
        <div class="card-header p-0 position-relative mt-n4 mx-3  z-index-2 ">
          <a class="d-block blur-shadow-image">
            <?php echo "<img src=../admin/images/$user[images]"; ?>
          </a>
          <div class="colored-shadow " style="background-image: url(&quot;https://demos.creative-tim.com/test/material-dashboard-pro/assets/img/products/product-1-min.jpg&quot;);"></div>
        </div>
        <div class="card-body text-center">

          <h5 class="font-weight-normal mt-3">
            <a href="javascript:;"><?php echo $user['product_name']; ?></a>
          </h5>
          <p class="mb-0">
            <?php echo $user['description']; ?>
          </p>
        </div>
        <hr class="dark horizontal my-0">
        <div class="card-footer d-flex ">
          <p class="font-weight-normal mx-5 my-auto">$<?php echo $user['price']; ?></p>
          <button type="button" class="btn bg-gradient-info mb-0 h-100 position-relative z-index-2">Buy</button>
        </div>

      </div>

    <?php
    }
    ?>

  </div>


  <style>
    /* Tr phone Post */

    .phone-item {
      background-color: #fff;
    }

    .phone-tab .nav-tabs {
      margin-bottom: 60px;
      border-bottom: 0;
    }

    .phone-tab .nav-tabs>li {
      float: none;
      display: inline;
    }

    .phone-tab .nav-tabs li {
      margin-right: 15px;
    }

    .phone-tab .nav-tabs li:last-child {
      margin-right: 0;
    }

    .phone-tab .nav-tabs {
      position: relative;
      z-index: 1;
      display: inline-block;
    }

    .phone-tab .nav-tabs:after {
      position: absolute;
      content: "";
      top: 50%;
      left: 0;
      width: 100%;
      height: 1px;
      background-color: #fff;
      z-index: -1;
    }



    .phone-tab .nav-tabs>li a {
      display: inline-block;
      background-color: #fff;
      border: none;
      border-radius: 30px;
      font-size: 14px;
      color: #000;
      padding: 5px 30px;
    }

    .phone-tab .nav-tabs>li>a.active,
    .phone-tab .nav-tabs>li a.active>:focus,
    .phone-tab .nav-tabs>li>a.active:hover,
    .phone-tab .nav-tabs>li>a:hover {
      border: none;
      background-color: #008def;
      color: #fff;
    }

    .phone-item {
      border-radius: 3px;
      position: relative;
      margin-bottom: 30px;
      z-index: 1;
    }

    .phone-item .btn.btn-primary {
      text-transform: capitalize;
    }

    .phone-item .phone-info {
      font-size: 14px;
      color: #000;
      overflow: hidden;
      padding: 40px 25px 20px;
    }

    .phone-info .company-logo {
      margin-bottom: 30px;
    }

    .phone-info .tr-title {
      margin-bottom: 15px;
    }

    .phone-info .tr-title span {
      font-size: 14px;
      display: block;
    }

    .phone-info .tr-title a {
      color: #000;
    }

    .phone-info .tr-title a:hover {
      color: #008def;
    }

    .phone-info ul {
      margin-bottom: 30px;
    }

    .phone-meta li,
    .phone-meta li a {
      color: #646464;
    }

    .phone-meta li a:hover {
      color: #008def;
    }

    .phone-meta li {
      font-size: 12px;
      margin-bottom: 10px;
    }

    .phone-meta li span i {
      color: #000;
    }

    .phone-meta li i {
      margin-right: 15px;
    }

    .phone-item .time {
      position: relative;
    }

    .phone-item .time:after {
      position: absolute;
      content: "";
      bottom: 35px;
      left: -50px;
      width: 150%;
      height: 1px;
      background-color: #f5f4f5;
      z-index: -1;
    }

    .phone-item:hover .time,
    .phone-item:hover .time:after {
      opacity: 0;
    }

    .phone-item .time span {
      font-size: 12px;
      color: #bebebe;
      line-height: 25px;
    }

    .phone-item .btn.btn-primary,
    .role .btn.btn-primary,
    .phone-item .time a span {
      padding: 5px 10px;
      border-radius: 4px;
      line-height: 10px;
      font-size: 12px;
    }

    .phone-item .time a span {
      color: #fff;
      background-color: #f1592a;
      border-color: #f1592a;
    }

    .phone-item .time a span.part-time {
      background-color: #00aeef;
      border-color: #00aeef;
    }

    .phone-item .time a span.freelance {
      background-color: #92278f;
      border-color: #92278f;
    }

    .phone-item .item-overlay {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      border-radius: 5px;
      background-color: #008def;
      color: #fff;
      opacity: 0;
      -webkit-transition: all 800ms;
      -moz-transition: all 800ms;
      -ms-transition: all 800ms;
      -o-transition: all 800ms;
      transition: all 800ms;
    }

    .phone-item:hover .item-overlay {
      opacity: 1;
    }

    .item-overlay .phone-info {
      padding: 45px 25px 40px;
      overflow: hidden;
    }

    .item-overlay .btn.btn-primary {
      background-color: #007bd4;
      border-color: #007bd4;
      margin-bottom: 10px;
    }

    .item-overlay .phone-info,
    .item-overlay .phone-info ul li,
    .item-overlay .phone-info ul li i,
    .item-overlay .phone-info .tr-title a {
      color: #fff;
    }

    .phone-social {
      margin-top: 35px;
    }

    .phone-social li {
      float: left;
    }

    .phone-social li+li {
      margin-left: 15px;
    }

    .phone-social li a i {
      margin-right: 0;
      font-size: 14px;
    }

    .phone-social li a {
      width: 35px;
      height: 35px;
      text-align: center;
      display: block;
      background-color: #007bd4;
      line-height: 35px;
      border-radius: 100%;
      border: 1px solid #007bd4;
      position: relative;
      overflow: hidden;
      z-index: 1;
    }

    .phone-social li:last-child a {
      background-color: #fff;
    }

    .phone-social li:last-child a i {
      color: #008def;
    }

    .phone-social li a:before {
      position: absolute;
      content: "";
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      z-index: -1;
      border-radius: 100%;
      background-color: #008def;
      -webkit-transform: scale(0);
      -moz-transform: scale(0);
      -ms-transform: scale(0);
      transform: scale(0);
    }

    .phone-social li a:hover:before {
      -webkit-transform: scale(1);
      -moz-transform: scale(1);
      -ms-transform: scale(1);
      transform: scale(1);
      padding: 5px;
    }

    .phone-social li a:hover {
      border-color: #fff;
    }

    .phone-social li a:hover i {
      color: #fff;
    }

    .tr-list {
      margin: 0;
      padding: 0;
      list-style: none;
    }
  </style>











  <div class="container ">
    <div class="row">
      <div class="row justify-content-center text-center my-sm-5">
        <div class="col-lg-6">
          <span class="badge bg-info mb-3">Phones</span>
          <h2 class="text-dark mb-0">Here is our phones</h2>
          <p class="lead">We make it easier to find what you want</p>
        </div>
      </div>
    </div>
  </div>

  <div class="tr-phone-posted section-padding">
    <div class="container">
      <div class="phone-tab text-center">
        <ul class="nav nav-tabs justify-content-center" role="tablist">
          <li role="presentation" class="active">
            <a class="active show" href="#apple" aria-controls="apple" role="tab" data-toggle="tab" aria-selected="true">Apple</a>
          </li>
          <li role="presentation"><a href="#samsung" aria-controls="samsung" role="tab" data-toggle="tab" class="" aria-selected="false">Samsung</a></li>
          <li role="presentation"><a href="#google" aria-controls="google" role="tab" data-toggle="tab" class="" aria-selected="false">Google</a></li>
          <li role="presentation"><a href="#oppo" aria-controls="oppo" role="tab" data-toggle="tab" class="" aria-selected="false">Oppo</a></li>
          <li role="presentation"><a href="#xiaomi" aria-controls="xiaomi" role="tab" data-toggle="tab" class="" aria-selected="false">Xiaomi</a></li>
        </ul>
        <div class="tab-content text-left">
          <div role="tabpanel" class="tab-pane fade active show" id="apple">
            <div class="row">
              <?php
              include_once('../db/connection.php');
              $a = 1;
              $stmt = $dbh->prepare(
                "SELECT * FROM products WHERE product_cat='apple'"
              );
              $stmt->execute();
              $users = $stmt->fetchAll();
              foreach ($users as $user) {
              ?>
                <div class="col-md-6 col-lg-3">
                  <form class="" action="" method="post">


                    <div class="phone-item">

                      <div class="phone-info">
                        <div class="company-logo">

                          <?php echo "<img class='img-fluid' src=../admin/images/$user[images] alt='images'>"; ?>
                        </div>
                        <span class="tr-title">
                          <a href="#"><?php echo $user['product_name']; ?></a>

                        </span>
                        <ul class="tr-list phone-meta">
                          <li><span><i class="fa fa-money" aria-hidden="true"></i></span>$<?php echo $user['price']; ?></li>
                        </ul>
                        <a href="details.php?edit_id=<?php print($user['id']); ?>"><button type="button" class="btn bg-gradient-info">CheckOut </button></a>
                      </div>
                    </div>
                  </form>
                </div>
              <?php
              }
              ?>



            </div><!-- /.row -->
          </div><!-- /.tab-pane -->
          <div role="tabpanel" class="tab-pane fade in" id="samsung">
            <div class="row">
              <?php
              include_once('../db/connection.php');
              $a = 1;
              $stmt = $dbh->prepare(
                "SELECT * FROM products WHERE product_cat='samsung'"
              );
              $stmt->execute();
              $users = $stmt->fetchAll();
              foreach ($users as $user) {
              ?>
                <div class="col-md-6 col-lg-3">
                  <div class="phone-item">

                    <div class="phone-info">
                      <div class="company-logo">

                        <?php echo "<img class='img-fluid' src=../admin/images/$user[images] alt='images'>"; ?>
                      </div>
                      <span class="tr-title">
                        <a href="#"><?php echo $user['product_name']; ?></a>

                      </span>
                      <ul class="tr-list phone-meta">
                        <li><span><i class="fa fa-money" aria-hidden="true"></i></span>$<?php echo $user['price']; ?></li>
                      </ul>
                      <a href="details.php?edit_id=<?php print($user['id']); ?>"><button type="button" class="btn bg-gradient-info">CheckOut </button></a>
                    </div>
                  </div>
                </div>
              <?php
              }
              ?>



            </div><!-- /.row -->
          </div><!-- /.tab-pane -->
          <div role="tabpanel" class="tab-pane fade in" id="google">
            <div class="row">
              <?php
              include_once('../db/connection.php');
              $a = 1;
              $stmt = $dbh->prepare(
                "SELECT * FROM products WHERE product_cat='google'"
              );
              $stmt->execute();
              $users = $stmt->fetchAll();
              foreach ($users as $user) {
              ?>
                <div class="col-md-6 col-lg-3">
                  <div class="phone-item">

                    <div class="phone-info">
                      <div class="company-logo">

                        <?php echo "<img class='img-fluid' src=../admin/images/$user[images] alt='images'>"; ?>
                      </div>
                      <span class="tr-title">
                        <a href="#"><?php echo $user['product_name']; ?></a>

                      </span>
                      <ul class="tr-list phone-meta">
                        <li><span><i class="fa fa-money" aria-hidden="true"></i></span>$<?php echo $user['price']; ?></li>
                      </ul>
                      <a href="details.php?edit_id=<?php print($user['id']); ?>"><button type="button" class="btn bg-gradient-info">CheckOut </button></a>
                    </div>
                  </div>
                </div>

              <?php
              }
              ?>


            </div><!-- /.row -->
          </div><!-- /.tab-pane -->



          <div role="tabpanel" class="tab-pane fade in" id="oppo">
            <div class="row">
              <?php
              include_once('../db/connection.php');
              $a = 1;
              $stmt = $dbh->prepare(
                "SELECT * FROM products WHERE product_cat='oppo'"
              );
              $stmt->execute();
              $users = $stmt->fetchAll();
              foreach ($users as $user) {
              ?>
                <div class="col-md-6 col-lg-3">
                  <div class="phone-item">

                    <div class="phone-info">
                      <div class="company-logo">

                        <?php echo "<img class='img-fluid' src=../admin/images/$user[images] alt='images'>"; ?>
                      </div>
                      <span class="tr-title">
                        <a href="#"><?php echo $user['product_name']; ?></a>

                      </span>
                      <ul class="tr-list phone-meta">
                        <li><span><i class="fa fa-money" aria-hidden="true"></i></span>$<?php echo $user['price']; ?></li>
                      </ul>
                      <button type="button" class="btn bg-gradient-info">CheckOut</button>
                    </div>
                  </div>
                </div>

              <?php
              }
              ?>


            </div><!-- /.row -->
          </div><!-- /.tab-pane -->
          <div role="tabpanel" class="tab-pane fade in" id="xiaomi">
            <div class="row">
              <?php
              include_once('../db/connection.php');
              $a = 1;
              $stmt = $dbh->prepare(
                "SELECT * FROM products WHERE product_cat='xiaomi'"
              );
              $stmt->execute();
              $users = $stmt->fetchAll();
              foreach ($users as $user) {
              ?>
                <div class="col-md-6 col-lg-3">
                  <div class="phone-item">

                    <div class="phone-info">
                      <div class="company-logo">

                        <?php echo "<img class='img-fluid' src=../admin/images/$user[images] alt='images'>"; ?>
                      </div>
                      <span class="tr-title">
                        <a href="#"><?php echo $user['product_name']; ?></a>

                      </span>
                      <ul class="tr-list phone-meta">
                        <li><span><i class="fa fa-money" aria-hidden="true"></i></span>$<?php echo $user['price']; ?></li>
                      </ul>
                      <a href="details.php?edit_id=<?php print($user['id']); ?>"><button type="button" class="btn bg-gradient-info">CheckOut </button></a>
                    </div>
                  </div>
                </div>

              <?php
              }
              ?>


            </div><!-- /.row -->
          </div><!-- /.tab-pane -->

        </div>
      </div><!-- /.phone-tab -->
    </div><!-- /.container --->
  </div>



</div>

<!-- Cart -->

<div id="exampleModal" class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">

      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Shopping Cart</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">


        <div>
          <div class="row">
            <div class="col-md-12 col-lg-8 mb-3">


              <div class="row">
                <div class="col-md-3">
                  <?php echo "<img class='img-fluid mx-auto d-block image' src=../admin/images/$user[images]>"; ?>
                  <!-- <img class="img-fluid mx-auto d-block image" src="../admin/images/galaxyNote20Ultra.jpg"> -->
                </div>
                <div class="col-md-8">
                  <div class="info">
                    <div class="row">
                      <div class="column">
                        <div>
                          <div class="product-name">
                            <a href="#"><?php echo $user['product_name']; ?></a>

                          </div>
                          <div class="d-flex align-items-center">
                            <div class="">
                              <label class="me-5 my-1" for="quantity">Quantity:</label>
                            </div>
                            <div class="">
                              <input id="quantity" type="number" value="1" class="w-50 form-control">
                            </div>

                          </div>
                        </div>
                        <div>
                          <span>$120</span>
                        </div>
                      </div>

                    </div>
                  </div>
                </div>
              </div>

            </div>




            <div class="col-md-12 col-lg-4">
              <div class="summary">
                <h3>Summary</h3>
                <div class="summary-item"><span class="text me-5">Total</span><span class="price">$360</span></div>

              </div>
            </div>
          </div>
        </div>






      </div>
      <div class="modal-footer">
        <button type="button" class="btn bg-gradient-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn bg-gradient-info">CheckOut</button>
      </div>
    </div>
  </div>
</div>