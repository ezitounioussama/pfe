<?php

require_once("inc/header.php");
require_once("inc/navbar.php");
require_once("inc/home.php");










require_once("inc/pagefooter.php");
require_once("inc/footer.php");
