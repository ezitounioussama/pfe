<?php
include 'inc/header.php';
include 'inc/navbar.php';
?>



<style>
    body {
        font-family: 'Roboto Condensed', sans-serif;
        background-color: #f5f5f5
    }

    .hedding {
        font-size: 20px;
        color: #ab8181;
    }

    .main-section {
        position: absolute;
        left: 50%;
        right: 50%;
        transform: translate(-50%, 5%);
    }

    .left-side-product-box img {
        width: 100%;
    }

    .left-side-product-box .sub-img img {
        margin-top: 5px;
        width: 83px;
        height: 100px;
    }

    .right-side-pro-detail span {
        font-size: 15px;
    }

    .right-side-pro-detail p {
        font-size: 25px;
        color: #a1a1a1;
    }

    .right-side-pro-detail .price-pro {
        color: #E45641;
    }

    .right-side-pro-detail .tag-section {
        font-size: 18px;
        color: #5D4C46;
    }

    .pro-box-section .pro-box img {
        width: 100%;
        height: 200px;
    }

    @media (min-width:360px) and (max-width:640px) {
        .pro-box-section .pro-box img {
            height: auto;
        }
    }
</style>
<?php
// Show PHP errors
ini_set('display_errors', 1);
ini_set('display_startup_erros', 1);
error_reporting(E_ALL);

require_once 'classes/dtls.php';

$objUser = new phone();
// GET
if (isset($_GET['edit_id'])) {
    $id = $_GET['edit_id'];
    $stmt = $objUser->runQuery("SELECT * FROM products WHERE id=:id");
    $stmt->execute(array(":id" => $id));
    $rowUser = $stmt->fetch(PDO::FETCH_ASSOC);
} else {
    $id = null;
    $rowUser = null;
}



?>
<div class="container m-6">
    <div class="col-lg-8 border p-3 main-section bg-white">
        <div class="row hedding m-0 pl-3 pt-0 pb-3">
            Product details :
        </div>
        <div class="row m-0">
            <div class="col-lg-4 left-side-product-box pb-3">
                <img src="../admin/images/<?php print($rowUser['images']); ?>" class="border p-3">

            </div>
            <div class="col-lg-8">
                <div class="right-side-pro-detail border p-3 m-0">
                    <div class="row">
                        <div class="col-lg-12">
                            <p class="m-0 p-0"><?php print($rowUser['product_name']); ?></p>
                        </div>
                        <div class="col-lg-12">
                            <p class="m-0 p-0 price-pro">$<?php print($rowUser['price']); ?></p>
                            <hr class="p-0 m-2">
                        </div>
                        <div class="col-lg-12 pt-2">
                            <h5>Product Detail</h5>
                            <span><?php print($rowUser['description']); ?></span>
                            <hr class="p-0 m-2">
                        </div>
                        <div class="col-lg-12 mt-3">
                            <div class="row">
                                <div class="col-lg-6 pb-2">
                                    <a href="#" class="btn btn-info w-100">Add To Cart</a>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<?php


?>
<!-- Cart -->

<div id="exampleModal" class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Shopping Cart</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">


                <div>
                    <div class="row">
                        <div class="col-md-12 col-lg-8 mb-3">


                            <div class="row">
                                <div class="col-md-3">

                                    <?php echo "<img class='img-fluid mx-auto d-block image' src=../admin/images/$rowUser[images]>"; ?>

                                </div>
                                <div class="col-md-8">
                                    <div class="info">
                                        <div class="row">
                                            <div class="column">
                                                <div>
                                                    <div class="product-name">
                                                        <a href="#"><?php echo $rowUser['product_name']; ?></a>

                                                    </div>
                                                    <div class="d-flex align-items-center">
                                                        <div class="">
                                                            <label class="me-5 my-1" for="quantity">Quantity:</label>
                                                        </div>
                                                        <div class="">
                                                            <input id="quantity" type="number" value="1" class="w-50 form-control">
                                                        </div>

                                                    </div>
                                                </div>
                                                <div>
                                                    <span>$120</span>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>




                        <div class="col-md-12 col-lg-4">
                            <div class="summary">
                                <h3>Summary</h3>
                                <div class="summary-item"><span class="text me-5">Total</span><span class="price">$360</span></div>

                            </div>
                        </div>
                    </div>
                </div>






            </div>
            <div class="modal-footer">
                <button type="button" class="btn bg-gradient-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn bg-gradient-info">CheckOut</button>
            </div>
        </div>
    </div>
</div>
<?php
include 'inc/footer.php';
?>