<?php

require_once('inc/header.php');
require_once('inc/nav.php');
require_once('home.php');
require_once('dashboard.php');

require_once('inc/footer.php');
