<?php

require_once 'database.php';

class User
{
    private $conn;

    // Constructor
    public function __construct()
    {
        $database = new Database();
        $db = $database->dbConnection();
        $this->conn = $db;
    }


    // Execute queries SQL
    public function runQuery($sql)
    {
        $stmt = $this->conn->prepare($sql);
        return $stmt;
    }

    // // Insert
    // public function insert($name, $desc, $function, $id)
    // {
    //     try {
    //         $stmt = $this->conn->prepare("INSERT INTO login (name, description, function) VALUES(:name, :desc , :function)");
    //         $stmt->bindparam(":name", $name);
    //         $stmt->bindparam(":desc", $desc);
    //         $stmt->bindparam(":function", $function);
    //         $stmt->execute();
    //         return $stmt;
    //     } catch (PDOException $e) {
    //         echo $e->getMessage();
    //     }
    // }


    // Update
    public function update($name, $desc, $cat, $price, $qte, $id)
    {
        try {
            $stmt = $this->conn->prepare("UPDATE products SET product_name = :name, description = :desc ,product_cat = :cat, price = :price, qte = :qte  WHERE id = :id");
            $stmt->bindparam(":name", $name);
            $stmt->bindparam(":desc", $desc);
            $stmt->bindparam(":cat", $cat);
            $stmt->bindparam(":price", $price);
            $stmt->bindparam(":qte", $qte);
            $stmt->bindparam(":id", $id);
            $stmt->execute();
            return $stmt;
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
    }


    // // Delete
    // public function delete($id)
    // {
    //     try {
    //         $stmt = $this->conn->prepare("DELETE FROM login WHERE id = :id");
    //         $stmt->bindparam(":id", $id);
    //         $stmt->execute();
    //         return $stmt;
    //     } catch (PDOException $e) {
    //         echo $e->getMessage();
    //     }
    // }

    // Redirect URL method
    public function redirect($url)
    {
        header("Location: $url");
    }
}
