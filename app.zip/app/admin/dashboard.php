<?php

require_once('inc/header.php');
require_once('inc/nav.php');
require_once('../db/connection.php');
?>

<div class="relative md:pt-32 pb-32 pt-12 " style="background-color: rgba(255, 0, 55, 0.95);">
  <div class="px-4 md:px-10 mx-auto w-full">
    <div>
      <!-- Card stats -->
      <div class="flex justify-center flex-wrap">

        <div class="w-full xl:w-3/12 px-4">
          <div class="relative flex flex-col min-w-0 break-words bg-white rounded mb-6 xl:mb-0 shadow-lg">
            <div class="flex-auto p-4">
              <div class="flex flex-wrap">
                <div class="relative w-full pr-4 max-w-full flex-grow flex-1">

                  <h5 class="text-blueGray-400 uppercase font-bold text-xs">
                    users
                  </h5>
                  <span class="font-semibold text-xl text-blueGray-700">
                    <?php

                    $servername = "localhost";
                    $username = "root";
                    $password = "";
                    $db = "webapp";
                    // Create connection
                    $conn = new mysqli($servername, $username, $password, $db);

                    $dash = "select * from login";
                    $dash_run = mysqli_query($conn, $dash);

                    if ($dash_total = mysqli_num_rows($dash_run)) {
                      echo $dash_total;
                    }

                    ?>
                  </span>
                </div>
                <div class="relative w-auto pl-4 flex-initial">
                  <div class="text-white p-3 text-center inline-flex items-center justify-center w-12 h-12 shadow-lg rounded-full bg-orange-500">
                    <i class="fas fa-chart-pie"></i>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>

        <div class="w-full xl:w-6/12 xl:w-3/12 px-4">
          <div class="relative flex flex-col min-w-0 break-words bg-white rounded mb-6 xl:mb-0 shadow-lg">
            <div class="flex-auto p-4">
              <div class="flex flex-wrap">
                <div class="relative w-full pr-4 max-w-full flex-grow flex-1">
                  <h5 class="text-blueGray-400 uppercase font-bold text-xs">
                    Phones
                  </h5>
                  <span class="font-semibold text-xl text-blueGray-700">
                    <?php

                    $servername = "localhost";
                    $username = "root";
                    $password = "";
                    $db = "webapp";
                    // Create connection
                    $conn = new mysqli($servername, $username, $password, $db);

                    $dash = "select * from products";
                    $dash_run = mysqli_query($conn, $dash);

                    if ($dash_total = mysqli_num_rows($dash_run)) {
                      echo $dash_total;
                    }

                    ?>
                  </span>
                </div>
                <div class="relative w-auto pl-4 flex-initial">
                  <div class="text-white p-3 text-center inline-flex items-center justify-center w-12 h-12 shadow-lg rounded-full bg-pink-500">
                    <i class="fas fa-mobile"></i>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>




<!-- chart -->

<div class="px-4 xl2:px-10 mx-auto w-full -m-24">
  <div class="flex flex-wrap">
    <div class="w-full xl2:w-8/12 mb-12 xl:mb-0 px-4">
      <div class="relative flex flex-col min-w-0 break-words w-full mb-6 shadow-lg rounded" style="background-color: rgb(0, 29, 42);">
        <div class="rounded-t mb-0 px-4 py-3 bg-transparent">
          <div class="flex flex-wrap items-center">
            <div class="relative w-full max-w-full flex-grow flex-1">
              <h6 class="uppercase text-blueGray-100 mb-1 text-xs font-semibold">
                Overview
              </h6>
              <h2 class="text-white text-xl font-semibold">
                Sales value
              </h2>
            </div>
          </div>
        </div>
        <div class="p-4 flex-auto">

          <div class="relative">
            <canvas id="pie-chart"></canvas>
          </div>
        </div>
      </div>
    </div>
  </div>




  <div class="flex flex-wrap mt-4">
    <div class="w-full xl2:w-8/12 mb-12 xl:mb-0 px-4">
      <div class="relative flex flex-col min-w-0 break-words bg-white w-full mb-6 shadow-lg rounded">
        <div class="rounded-t mb-0 px-4 py-3 border-0">
          <div class="flex flex-wrap items-center">
            <div class="relative w-full px-4 max-w-full flex-grow flex-1">
              <h3 class="font-semibold text-base text-blueGray-700">
                Stock
              </h3>
            </div>

            <canvas id="bar-chart-horizontal" width="800" height="300"></canvas>
          </div>
        </div>
        <!-- <?php
              $phpconnect = mysqli_connect("localhost", "root", "", "webapp");

              if (mysqli_connect_errno()) {
                echo "Connection Failed; " . mysqli_connect_error();
              } else {
                echo "Connection Established.<br>";
              }

              mysqli_close($phpconnect);
              echo "Connection Closed"
              ?>


        <?php
        header('Content-Type: application/json');

        $sqlQuery = "SELECT qte FROM products ORDER BY qte";

        $result = mysqli_query($conn, $sqlQuery);

        $data = array();
        foreach ($result as $row) {
          $data[] = $row;
        }

        mysqli_close($conn);

        echo json_encode($data);
        ?>   -->

        <?php
        require_once('inc/footer.php');
        ?>