<?php
// Show PHP errors
ini_set('display_errors', 1);
ini_set('display_startup_erros', 1);
error_reporting(E_ALL);

require_once 'classes/pdt.php';

$objUser = new User();
// GET
if (isset($_GET['edit_id'])) {
    $id = $_GET['edit_id'];
    $stmt = $objUser->runQuery("SELECT * FROM products WHERE id=:id");
    $stmt->execute(array(":id" => $id));
    $rowUser = $stmt->fetch(PDO::FETCH_ASSOC);
} else {
    $id = null;
    $rowUser = null;
}

// POST
if (isset($_POST['btn_save'])) {

    $name   = strip_tags($_POST['name']);
    $desc  = strip_tags($_POST['desc']);
    $cat  = strip_tags($_POST['cat']);
    $price = strip_tags($_POST['price']);
    $qte = strip_tags($_POST['qte']);
    try {
        if ($id != null) {
            if ($objUser->update($name, $desc, $cat, $price, $qte, $id)) {
                $objUser->redirect('products.php?updated#product');
            }
        } else {

            $objUser->redirect('products.php?error#product');
        }
    } catch (PDOException $e) {
        echo $e->getMessage();
    }
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <!--=============== BOXICONS ===============-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">

    <!--=============== CSS ===============-->
    <link rel="stylesheet" href="modal_assets/css/styles.css">


    <title>Edit</title>
</head>

<body>
    <section class="modal container">
        <button class="modal__button" id="open-modal">
            Open To Edit
        </button>

        <div class="modal__container" id="modal-container">
            <div class="modal__content">
                <div class="modal__close close-modal" title="Close">
                    <i class='bx bx-x'></i>
                </div>
                <h1 class="modal__title">Edit Products</h1>

                <div class="form-container">

                    <form method="post">
                        <div class="form-group">
                            <label for="id">ID</label>
                            <input class="form-control" type="text" name="id" id="id" value="<?php print($rowUser['id']); ?>" readonly>
                        </div>
                        <div class="form-group">
                            <label for="name">Product name *</label>
                            <input class="form-control" type="text" name="name" id="name" value="<?php print($rowUser['product_name']); ?>" required maxlength="100">
                        </div>
                        <div class="form-group">
                            <label for="pass">description *</label>
                            <input class="form-control" type="text" name="desc" id="pass" value="<?php print($rowUser['description']); ?>" required maxlength="100">
                        </div>
                        <div class="form-group">
                            <label for="pass">cat </label>
                            <input class="form-control" type="text" name="cat" id="pass" value="<?php print($rowUser['product_cat']); ?>" required maxlength="100">
                        </div>
                        <div class="form-group">
                            <label for="function">price *</label>
                            <input class="form-control" type="text" name="price" id="function" value="<?php print($rowUser['price']); ?>" required maxlength="100">
                        </div>
                        <div class="form-group">
                            <label for="function">qte *</label>
                            <input class="form-control" type="text" name="qte" id="function" value="<?php print($rowUser['qte']); ?>" required maxlength="100">
                        </div>
                        <input class="modal__button modal__button-width" type="submit" name="btn_save" value="Save">
                </div>
                </form>



                <button class="modal__button-link close-modal">
                    Close
                </button>
            </div>
        </div>
    </section>

    <!--=============== MAIN JS ===============-->
    <script src="modal_assets/js/main.js"></script>
</body>

</html>